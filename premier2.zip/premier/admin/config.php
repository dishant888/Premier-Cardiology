<?php 
$con=mysqli_connect('localhost','wwwecoto_premier','admin@123','wwwecoto_premier');
if(!$con)
{
	die('<center><h1>Unable to connect...!</h1></center');
}
 ?>